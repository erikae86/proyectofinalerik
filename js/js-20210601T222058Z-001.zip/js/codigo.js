
function abrir(){

document.getElementById('formulario').style.display = 'block'



}


function cerrar(){

    document.getElementById('formulario').style.display = 'none'
    
    
    
    }